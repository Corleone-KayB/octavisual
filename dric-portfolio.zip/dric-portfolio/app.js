const express = require('express');
const path = require('path');

const app = express();
const PORT = process.env.PORT || 3000;

// View engine setup
app.set('view engine', 'ejs');
app.set('views', path.join(__dirname, 'views'));

// Static assets (css, images, js)
app.use(express.static(path.join(__dirname, 'public')));

// Routes
app.get('/', (req, res) => {
  res.render('home', { title: 'Dric Ent. — Home' });
});

app.listen(PORT, () => {
  console.log(`Dric Ent. site running at http://localhost:${PORT}`);
});
